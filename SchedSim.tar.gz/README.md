CS377_SchedSim
==============

Simulation of an OS scheduler. Handles I/O and CPU bursts according to the FCFS, SRFT, and SJF algorithms. 

NOTE: THIS IS THE GIT README. PLEASE SEE THE OTHER README'S (IN PDF AND .TXT FORMAT) FOR THE DESIGN DOCUMENT.