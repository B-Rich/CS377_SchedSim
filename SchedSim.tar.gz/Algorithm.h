enum Algorithm
{
	FCFS,
	SJF,
	SRTF
};
